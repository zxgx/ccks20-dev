train.xls等文件是similarity.py微调Bert模型时需要的数据
格式参考https://github.com/terrifyzhao/bert-utils/tree/master/data
